package com.example.kartuucapan

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val nameInput = findViewById<EditText>(R.id.nameInput)
        val messageInput = findViewById<EditText>(R.id.messageInput)
        val previewButton = findViewById<Button>(R.id.previewButton)

        previewButton.setOnClickListener {
            val name = nameInput.text.toString()
            val message = messageInput.text.toString()

            // Explicit Intent to PreviewActivity
            val intent = Intent(this, PreviewActivity::class.java).apply {
                putExtra("EXTRA_NAME", name)
                putExtra("EXTRA_MESSAGE", message)
            }
            startActivity(intent)
        }
    }
}
