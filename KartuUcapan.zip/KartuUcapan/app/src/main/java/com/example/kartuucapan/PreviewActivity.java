package com.example.kartuucapan;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.example.kartuucapan.R;

public class PreviewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preview);

        // Mendapatkan data dari Intent
        String name = getIntent().getStringExtra("EXTRA_NAME");
        String message = getIntent().getStringExtra("EXTRA_MESSAGE");
        String creatorName = getIntent().getStringExtra("EXTRA_CREATOR_NAME");

        // Menemukan view berdasarkan id
        TextView messageView = findViewById(R.id.messageView);
        TextView nameView = findViewById(R.id.nameView);
        TextView creatorNameView = findViewById(R.id.creatorNameView);
        Button shareButton = findViewById(R.id.shareButton);

        // Menampilkan pesan di TextView
        messageView.setText(message);
        nameView.setText("Untuk: " + name);
        creatorNameView.setText("Dari: " + creatorName); // Menampilkan nama pembuat

        // Implicit Intent untuk berbagi pesan
        shareButton.setOnClickListener(v -> {
            Intent shareIntent = new Intent();
            shareIntent.setAction(Intent.ACTION_SEND);
            shareIntent.putExtra(Intent.EXTRA_TEXT, "To: " + name + "\n" + message + "\nFrom: " + creatorName);
            shareIntent.setType("text/plain");
            startActivity(Intent.createChooser(shareIntent, "Share via"));
        });
    }
}
